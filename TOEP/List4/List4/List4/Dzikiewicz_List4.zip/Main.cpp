#include <iostream>
#include "CTreeDynamic.h"

int main()
{
	vTreeTestDynamic();

	return 0;
}