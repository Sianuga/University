#include "Node.h"
#include <cstddef>


Node::Node(int val)
{
	_val = val;
	left = NULL;
	right = NULL;
}

Node::~Node()
{
	
}



