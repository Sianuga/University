import GUI
import tkinter as tk


def main():
    root = tk.Tk()
    logViewer = GUI.LogViewer(root)
    root.mainloop()


if __name__ == "__main__":
    main()
    

