import sys



for line in sys.stdin: