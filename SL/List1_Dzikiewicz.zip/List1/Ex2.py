import sys

def ex2():
    for line in sys.stdin:
    print(line.split(" "))
    break


 